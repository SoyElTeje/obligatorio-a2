#include <iostream>
#include "grafoListaAdy.cpp"
using namespace std;

void DFS(GrafoLista* grafo, int nodoActual, bool * visitados){
    visitados[nodoActual] = true;
    // El procesado del nodo puede ser algo mucho mas complejo
    cout << nodoActual << endl;
    Arista* ady = grafo->adyacentes(nodoActual);
    while(ady){
        int V = ady->destino;
        if(!visitados[V]){
            DFS(grafo, V, visitados);
        }
        ady = ady->sig;
    }
}
int main(){
    GrafoLista * grafo = new GrafoLista(5, false, false);
    int V = grafo->cantidadVertices();
    bool * visitados = new bool[V + 1](); 
    grafo->agregarArista(1,2);
    grafo->agregarArista(1,4);
    grafo->agregarArista(3,4);
    grafo->agregarArista(5,4);
    grafo->agregarArista(3,2);
    DFS(grafo, 1, visitados);
    return 0;
}